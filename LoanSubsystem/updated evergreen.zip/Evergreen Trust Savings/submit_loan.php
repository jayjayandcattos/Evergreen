<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "loan_system";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$full_name      = $_POST['full_name'] ?? '';
$account_number = $_POST['account_number'] ?? '';
$contact_number = $_POST['contact_number'] ?? '';
$email          = $_POST['email'] ?? '';
$loan_type      = $_POST['loan_type'] ?? '';
$loan_terms     = $_POST['loan_terms'] ?? '';
$loan_amount    = $_POST['loan_amount'] ?? 0;
$loan_purpose   = $_POST['purpose'] ?? '';

$file_path = "";
if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] == 0) {
    $target_dir = "uploads/";
    if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);
    $file_path = $target_dir . basename($_FILES["attachment"]["name"]);
    move_uploaded_file($_FILES["attachment"]["tmp_name"], $file_path);
}

$sql = "INSERT INTO loan_applications 
(full_name, account_number, contact_number, email, loan_type, loan_terms, loan_amount, purpose, file_name) 
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssssiss", $full_name, $account_number, $contact_number, $email, $loan_type, $loan_terms, $loan_amount, $loan_purpose, $file_path);

if ($stmt->execute()) {
    echo "<script>alert('Loan Application Submitted Successfully!'); window.location.href='index.html';</script>";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
