<?php 
phpinfo();

?>
