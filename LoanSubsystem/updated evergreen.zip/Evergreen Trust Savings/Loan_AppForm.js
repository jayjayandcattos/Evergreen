// ================== MAIN MODAL HANDLING ==================

const combinedModal = document.getElementById('combined-modal');
const termsView = document.getElementById('terms-view');
const confirmationView = document.getElementById('confirmation-view');
const applicationContent = document.querySelector('.page-content');
const loanForm = document.getElementById('loanForm');

// === Show the Terms Modal ===
function openTerms() {
    combinedModal.style.visibility = 'visible';
    combinedModal.style.opacity = '1';
    termsView.classList.remove('hidden');
    confirmationView.classList.add('hidden');

    // Apply blur background
    applicationContent.classList.add('blur-background');
    document.body.style.overflow = 'hidden';

    // Initialize accordion inside modal
    setupAccordion();
}

// === Close Modal (used if user declines) ===
function closeModal() {
    combinedModal.style.opacity = '0';
    setTimeout(() => {
        combinedModal.style.visibility = 'hidden';
        applicationContent.classList.remove('blur-background');
        document.body.style.overflow = 'auto';
    }, 300);
}

// === Accept Terms and Show Confirmation ===
function acceptTerms() {
    // Hide terms section and show confirmation
    termsView.classList.add('hidden');
    confirmationView.classList.remove('hidden');

    // Generate reference details
    const now = new Date();
    document.getElementById("ref-date").innerText = now.toLocaleString();
    document.getElementById("ref-number").innerText =
        "EVG-" + Math.floor(Math.random() * 900000 + 100000);

    // Auto-submit the form to PHP backend
    const formData = new FormData(loanForm);

    fetch("submit_loan.php", {
        method: "POST",
        body: formData
    })
    .then(response => response.text())
    .then(result => {
        console.log("Server Response:", result);

        // Optional: log result or display additional messages
        if (!result.toLowerCase().includes("success")) {
            alert("⚠️ Submission completed, but server response indicates an issue:\n" + result);
        }
    })
    .catch(error => {
        console.error("Error:", error);
        alert("❌ An error occurred while submitting your loan application.");
    });
}

// === Accordion setup ===
function setupAccordion() {
    const headers = document.querySelectorAll('.accordion-header');

    headers.forEach(header => {
        header.addEventListener('click', () => {
            const item = header.closest('.accordion-item');
            if (item) item.classList.toggle('open');
        });
    });
}

// ================== FORM VALIDATION ==================

document.addEventListener("DOMContentLoaded", function () {
    if (!loanForm) return;

    const submitBtn = document.querySelector(".btn-submit");
    if (!submitBtn) return;

    submitBtn.addEventListener("click", function (event) {
        event.preventDefault();

        // ✅ Validate fields first
        if (!loanForm.checkValidity()) {
            alert("⚠️ Please complete all required fields before submitting.");
            return;
        }

        // ✅ Show Terms modal before submitting
        openTerms();
    });
});

// === Utility: allow dashboard redirect from confirmation ===
function goToDashboard() {
    closeModal();
    window.location.href = "index.html";
}
